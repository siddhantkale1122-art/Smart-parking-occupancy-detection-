import unittest

from src.occupancy_detection import detect_slots, validate_slots


class TestOccupancyDetection(unittest.TestCase):
    def setUp(self):
        self.slots = [
            {"id": "A1", "x": 0, "y": 0, "w": 100, "h": 100},
            {"id": "A2", "x": 100, "y": 0, "w": 100, "h": 100},
        ]

    def test_vehicle_overlap_marks_slot_occupied(self):
        vehicles = [{"class": "car", "confidence": 0.9, "x1": 10, "y1": 10, "x2": 80, "y2": 80}]
        result = detect_slots(self.slots, vehicles, 200, 100, 0.20)
        self.assertEqual(result[0]["status"], "Occupied")
        self.assertEqual(result[1]["status"], "Available")

    def test_no_vehicles_means_all_available(self):
        result = detect_slots(self.slots, [], 200, 100)
        self.assertTrue(all(row["status"] == "Available" for row in result))

    def test_zero_overlap_threshold_does_not_mark_empty_slots_occupied(self):
        result = detect_slots(self.slots, [], 200, 100, overlap_threshold=0.0)
        self.assertTrue(all(row["status"] == "Available" for row in result))

    def test_duplicate_ids_rejected(self):
        bad = [self.slots[0], {**self.slots[1], "id": "A1"}]
        with self.assertRaises(ValueError):
            validate_slots(bad, 200, 100)

    def test_out_of_bounds_rejected(self):
        bad = [{"id": "A1", "x": 190, "y": 0, "w": 20, "h": 20}]
        with self.assertRaises(ValueError):
            validate_slots(bad, 200, 100)


if __name__ == "__main__":
    unittest.main()
