# Implementation Notes and Requirement Alignment

## Implemented in this repository

- Streamlit user interface for uploading a parking-lot image or recorded video.
- Pretrained YOLOv8 nano object detection for cars, motorcycles, buses, and trucks.
- Manual rectangular parking-slot configuration (`id`, `x`, `y`, `w`, `h`) in image pixel coordinates.
- Slot occupancy classification based on the fraction of slot area overlapped by a detected vehicle box.
- Slot-level status table, aggregate counts, annotated image, and annotated-image download for image input.
- Sampled video processing with a configurable frame interval and maximum sampled-frame count.
- Unit tests for overlap classification and slot validation.

## Not implemented in this version

- Direct live CCTV/IP-camera streaming.
- Automatic discovery of parking-slot boundaries.
- Database, user authentication, reservations, payments, number-plate recognition, or gate control.
- Export of a fully annotated video file.
- A trained project-specific model or a measured accuracy claim.

## Important interpretation

The app's output is an estimate. YOLO detects vehicles; it does not itself identify parking-slot boundaries. The slot rectangles must be configured to fit the uploaded scene. The overlap threshold and detector confidence should be tuned on a labeled validation set. A grid is only a starting aid, not a substitute for correctly drawing the parking spaces.

## Documents supplied with the project

The PRD, TRD, FRD, and synopsis documents are included as editable Word files. They are initial drafts and should be reviewed against the implemented scope above before final college submission. In particular, statements about live camera feeds should be changed to uploaded image/recorded video unless live-stream support is implemented separately.

## Reproducible evaluation

Do not write an accuracy percentage in the report until you have tested against ground-truth labels. Record the dataset/source, number of images or sampled frames, test conditions, model/dependency versions, detector confidence, overlap threshold, and the metrics in `EVALUATION_TEMPLATE.md`.
