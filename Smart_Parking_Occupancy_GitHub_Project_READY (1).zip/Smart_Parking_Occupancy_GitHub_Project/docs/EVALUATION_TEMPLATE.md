# Evaluation Results Template

Fill this in after running the application on a labeled test set. Do not treat example values as results.

## Test setup

- Dataset/source and permission:
- Number of images:
- Number of video frames evaluated:
- Camera/viewpoint and lighting:
- Python version:
- YOLO model:
- Detector confidence threshold:
- Slot overlap threshold:
- Hardware:
- Date of evaluation:

## Slot-level metrics

| Metric | Measured result |
|---|---|
| True positives (occupied correctly predicted) | |
| False positives (available predicted occupied) | |
| False negatives (occupied predicted available) | |
| True negatives (available correctly predicted) | |
| Accuracy | |
| Precision for Occupied | |
| Recall for Occupied | |
| F1-score for Occupied | |
| Mean absolute occupancy-count error | |
| Average processing time per sampled frame | |

Definitions:

- Accuracy = (TP + TN) / (TP + TN + FP + FN)
- Precision = TP / (TP + FP)
- Recall = TP / (TP + FN)
- F1 = 2 × Precision × Recall / (Precision + Recall)
- Mean absolute occupancy-count error = mean of |predicted occupied count − ground-truth occupied count| per evaluated image/frame.

If a denominator is zero, state that the metric is undefined for that test set rather than reporting a misleading value.

## Observations and limitations

- Common false positives:
- Common false negatives:
- Effect of lighting, occlusion, perspective, and camera angle:
- Changes made after validation:
- Final limitations:
