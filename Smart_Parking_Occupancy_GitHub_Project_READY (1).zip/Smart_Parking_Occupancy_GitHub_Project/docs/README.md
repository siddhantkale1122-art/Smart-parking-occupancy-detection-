# Project Documents

This folder contains the supplied editable project documents:

- `PRD_Smart_Parking_Occupancy_Detection.docx` — product requirements
- `TRD_Smart_Parking_Occupancy_Detection.docx` — technical requirements
- `FRD_Smart_Parking_Occupancy_Detection.docx` — functional requirements
- `Synopsis_Smart_Parking_Occupancy_Detection.docx` — project synopsis

Also included:

- `IMPLEMENTATION_NOTES.md` — what the current code does and does not do
- `EVALUATION_TEMPLATE.md` — blank template for reporting real test results

The Word documents are initial drafts. Update them to match the final code, college format, student/team details, and actual measured results before submission. No performance results are fabricated by this repository.
