from __future__ import annotations

import json
import re
from typing import Any

import numpy as np
from PIL import Image


def parse_slots_json(raw: str) -> list[dict[str, Any]]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON on line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc
    if not isinstance(value, list):
        raise ValueError("Slot configuration must be a JSON list.")
    return value


def image_to_bgr(image: Image.Image) -> np.ndarray:
    rgb = np.asarray(image.convert("RGB"))
    return rgb[:, :, ::-1].copy()


def safe_filename(filename: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", filename).strip("._")
    return cleaned or "upload"
