from __future__ import annotations

from typing import Any

import cv2
import numpy as np


VEHICLE_CLASS_NAMES = {"car", "motorcycle", "bus", "truck"}


class OccupancyDetector:
    """YOLO-based vehicle detector. Requires ultralytics and downloads weights on first use."""

    def __init__(self, model_name: str = "yolov8n.pt"):
        try:
            from ultralytics import YOLO
        except ImportError as exc:
            raise RuntimeError(
                "The ultralytics package is not installed. Install dependencies from requirements.txt."
            ) from exc
        self.model = YOLO(model_name)

    def detect(self, frame_bgr: np.ndarray, confidence: float = 0.35) -> list[dict[str, Any]]:
        if frame_bgr is None or frame_bgr.size == 0:
            raise ValueError("Input frame is empty.")
        result = self.model.predict(
            source=frame_bgr,
            conf=float(confidence),
            verbose=False,
        )[0]
        detections: list[dict[str, Any]] = []
        names = result.names
        if result.boxes is None:
            return detections
        for box in result.boxes:
            cls_id = int(box.cls.item())
            class_name = str(names.get(cls_id, cls_id)).lower()
            if class_name not in VEHICLE_CLASS_NAMES:
                continue
            x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
            detections.append({
                "class": class_name,
                "confidence": float(box.conf.item()),
                "x1": max(0, x1),
                "y1": max(0, y1),
                "x2": min(frame_bgr.shape[1], x2),
                "y2": min(frame_bgr.shape[0], y2),
            })
        return detections


def validate_slots(slots: list[dict[str, Any]], width: int, height: int) -> None:
    if not isinstance(slots, list) or not slots:
        raise ValueError("Provide at least one parking slot.")
    seen_ids = set()
    for index, slot in enumerate(slots):
        if not isinstance(slot, dict):
            raise ValueError(f"Slot {index + 1} must be an object.")
        missing = {"id", "x", "y", "w", "h"} - set(slot)
        if missing:
            raise ValueError(f"Slot {index + 1} is missing fields: {', '.join(sorted(missing))}.")
        slot_id = str(slot["id"]).strip()
        if not slot_id:
            raise ValueError(f"Slot {index + 1} has an empty id.")
        if slot_id in seen_ids:
            raise ValueError(f"Duplicate slot id: {slot_id}.")
        seen_ids.add(slot_id)
        try:
            x, y, w, h = int(slot["x"]), int(slot["y"]), int(slot["w"]), int(slot["h"])
        except (ValueError, TypeError) as exc:
            raise ValueError(f"Slot {slot_id} coordinates must be integers.") from exc
        if x < 0 or y < 0 or w <= 0 or h <= 0:
            raise ValueError(f"Slot {slot_id} must have x/y >= 0 and w/h > 0.")
        if x + w > width or y + h > height:
            raise ValueError(
                f"Slot {slot_id} exceeds the image boundary ({width} × {height})."
            )


def _intersection_area(slot: dict[str, Any], vehicle: dict[str, Any]) -> int:
    sx1, sy1 = int(slot["x"]), int(slot["y"])
    sx2, sy2 = sx1 + int(slot["w"]), sy1 + int(slot["h"])
    vx1, vy1, vx2, vy2 = (
        int(vehicle["x1"]), int(vehicle["y1"]), int(vehicle["x2"]), int(vehicle["y2"])
    )
    iw = max(0, min(sx2, vx2) - max(sx1, vx1))
    ih = max(0, min(sy2, vy2) - max(sy1, vy1))
    return iw * ih


def detect_slots(
    slots: list[dict[str, Any]],
    vehicles: list[dict[str, Any]],
    width: int,
    height: int,
    overlap_threshold: float = 0.20,
) -> list[dict[str, Any]]:
    """Classify a slot occupied if a vehicle box overlaps enough of the slot area."""
    validate_slots(slots, width, height)
    if not 0 <= overlap_threshold <= 1:
        raise ValueError("overlap_threshold must be between 0 and 1.")
    output = []
    for slot in slots:
        slot_area = int(slot["w"]) * int(slot["h"])
        best_overlap = 0.0
        best_vehicle = None
        for vehicle in vehicles:
            overlap = _intersection_area(slot, vehicle) / max(slot_area, 1)
            if overlap > best_overlap:
                best_overlap = overlap
                best_vehicle = vehicle
        occupied = best_vehicle is not None and best_overlap >= overlap_threshold
        output.append({
            "slot_id": str(slot["id"]),
            "status": "Occupied" if occupied else "Available",
            "overlap_fraction": round(float(best_overlap), 3),
            "vehicle_class": best_vehicle["class"] if occupied and best_vehicle else "",
        })
    return output
