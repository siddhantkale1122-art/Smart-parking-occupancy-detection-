from __future__ import annotations

from typing import Any

import cv2
import numpy as np
import pandas as pd


def annotate_frame(
    frame_bgr: np.ndarray,
    slots: list[dict[str, Any]],
    vehicles: list[dict[str, Any]],
    statuses: list[dict[str, Any]],
) -> np.ndarray:
    """Draw slot boxes, status labels, and detected vehicle boxes on a BGR frame."""
    status_by_id = {row["slot_id"]: row for row in statuses}
    for slot in slots:
        slot_id = str(slot["id"])
        x, y = int(slot["x"]), int(slot["y"])
        x2, y2 = x + int(slot["w"]), y + int(slot["h"])
        status = status_by_id.get(slot_id, {}).get("status", "Configured")
        color = (0, 0, 255) if status == "Occupied" else (0, 200, 0)
        cv2.rectangle(frame_bgr, (x, y), (x2, y2), color, 2)
        label = f"{slot_id}: {status}"
        baseline_y = max(18, y - 7)
        cv2.putText(frame_bgr, label, (x, baseline_y), cv2.FONT_HERSHEY_SIMPLEX,
                    0.48, color, 2, cv2.LINE_AA)
    for vehicle in vehicles:
        x1, y1, x2, y2 = [int(vehicle[k]) for k in ("x1", "y1", "x2", "y2")]
        label = f'{vehicle["class"]} {vehicle["confidence"]:.2f}'
        cv2.rectangle(frame_bgr, (x1, y1), (x2, y2), (255, 160, 0), 2)
        cv2.putText(frame_bgr, label, (x1, min(frame_bgr.shape[0] - 5, y1 + 18)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 160, 0), 2, cv2.LINE_AA)
    return frame_bgr


def summary_counts(statuses: list[dict[str, Any]]) -> dict[str, float | int]:
    total = len(statuses)
    occupied = sum(row["status"] == "Occupied" for row in statuses)
    available = total - occupied
    return {
        "total": total,
        "occupied": occupied,
        "available": available,
        "occupancy_pct": (occupied / total * 100.0) if total else 0.0,
    }
